(() => {

    const BASE_END_POINT = "https://api.openweathermap.org/data/2.5/";
    const API_KEY = "ccb3237d7ddd720be6b9924082cc71f2";

    /**
     * Display weather for a given location
     * @param {Object} weatherData - The object of weather data. 
     */

    const displayWeather = (weatherData) => {
        console.log(weatherData);
    }

    /**
     * Display forcast for a given location
     * @param {Object} forcastData -object of entire forecast.
     */
    const displayForcast = (forcastData) => {
        console.log(forcastData);
    }

    //display forcasts for different cities
    document
        .querySelector('.frm.weather')
        .addEventListener('submit', (event) => {
            event.preventDefault();
            let location = event.target.querySelector("[name=location]").value
            console.log(`Weather for: ${location}`);


            let currentWeatherEndPoint = `${BASE_END_POINT}weather?q=${location}&appid=${API_KEY}&units=metric`;
            let forcastEndPoint = `${BASE_END_POINT}forecast?q=${location}&appid=${API_KEY}&units=metric`;
            fetch(currentWeatherEndPoint).then(response => {
                return response.json();
            }).then((weatherData) => {
                displayWeather(weatherData);
                return fetch(forcastEndPoint);
            }).then(response => {
                return response.json();
            }).then((forcastData) => {
                displayForcast(forcastData);
                console.log(forcastData);
            }).catch((error) => {
                console.log(`error${error}`)
            });


            console.log(location);
        })


})();